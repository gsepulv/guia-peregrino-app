import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../config/theme.dart';
import '../data/app_data.dart';

class InfoScreen extends StatefulWidget {
  const InfoScreen({super.key});

  @override
  State<InfoScreen> createState() => _InfoScreenState();
}

class _InfoScreenState extends State<InfoScreen> {
  String? _origenSeleccionado;
  String _medioTransporte = 'vehiculo';
  Map<String, dynamic>? _resultadoViaje;

  void _calcularViaje() {
    if (_origenSeleccionado == null) return;
    
    final datos = AppData.origenes[_origenSeleccionado];
    if (datos == null) return;

    final distancia = datos['distancia'] as int;
    int tiempo = datos['tiempo'] as int;
    int calorias = 0;

    if (_medioTransporte == 'caminando') {
      // A pie: ~5 km/h promedio
      tiempo = (distancia / 5 * 60).round();
      // Calorías: ~50 cal por km caminando
      calorias = distancia * 50;
    }

    setState(() {
      _resultadoViaje = {
        'distancia': distancia,
        'tiempo': tiempo,
        'calorias': calorias,
      };
    });
  }

  String _formatearTiempo(int minutos) {
    if (minutos < 60) return '$minutos min';
    final horas = minutos ~/ 60;
    final mins = minutos % 60;
    if (mins == 0) return '${horas}h';
    return '${horas}h ${mins}min';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ℹ️ Información'),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: AppTheme.headerGradient,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Emergencias
          _buildSectionTitle('🚨 Emergencias'),
          _buildEmergenciasCard(),
          
          const SizedBox(height: 24),
          
          // Calculadora de viaje
          _buildSectionTitle('🗺️ Calculadora de Viaje'),
          _buildCalculadoraCard(),
          
          const SizedBox(height: 24),
          
          // Contacto Parroquia
          _buildSectionTitle('✝️ Parroquia San Sebastián'),
          _buildParroquiaCard(),
          
          const SizedBox(height: 24),
          
          // Sobre la app
          _buildSectionTitle('📱 Sobre esta App'),
          _buildAboutCard(),
          
          const SizedBox(height: 100),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildEmergenciasCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildEmergenciaItem('🚑', 'Ambulancia (SAMU)', '131', Colors.red),
          const Divider(height: 1),
          _buildEmergenciaItem('🚒', 'Bomberos', '132', Colors.orange),
          const Divider(height: 1),
          _buildEmergenciaItem('🚓', 'Carabineros', '133', Colors.blue),
        ],
      ),
    );
  }

  Widget _buildEmergenciaItem(String icono, String nombre, String numero, Color color) {
    return ListTile(
      leading: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Center(
          child: Text(icono, style: const TextStyle(fontSize: 22)),
        ),
      ),
      title: Text(nombre),
      subtitle: Text(numero, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
      trailing: IconButton(
        icon: Icon(Icons.phone, color: color),
        onPressed: () => _llamar(numero),
      ),
    );
  }

  Widget _buildCalculadoraCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Selector de origen
          const Text(
            '¿Desde dónde vienes?',
            style: TextStyle(fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(12),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _origenSeleccionado,
                hint: const Text('Selecciona tu origen'),
                isExpanded: true,
                items: AppData.origenes.keys.map((origen) {
                  return DropdownMenuItem(
                    value: origen,
                    child: Text(origen),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _origenSeleccionado = value;
                    _resultadoViaje = null;
                  });
                },
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Selector de transporte
          const Text(
            'Medio de transporte',
            style: TextStyle(fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _buildTransporteOption('caminando', '🚶', 'Caminando'),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildTransporteOption('vehiculo', '🚗', 'Vehículo'),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          // Botón calcular
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _origenSeleccionado != null ? _calcularViaje : null,
              icon: const Text('🦉', style: TextStyle(fontSize: 20)),
              label: const Text('Calcular con el Búho'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
          
          // Resultado
          if (_resultadoViaje != null) ...[
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.primaryColor.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.primaryColor.withOpacity(0.2),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildResultItem(
                    '📏',
                    '${_resultadoViaje!['distancia']} km',
                    'Distancia',
                  ),
                  _buildResultItem(
                    '⏱️',
                    _formatearTiempo(_resultadoViaje!['tiempo']),
                    'Tiempo',
                  ),
                  if (_medioTransporte == 'caminando')
                    _buildResultItem(
                      '🔥',
                      '${_resultadoViaje!['calorias']}',
                      'Calorías',
                    ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTransporteOption(String value, String icono, String label) {
    final isSelected = _medioTransporte == value;
    return GestureDetector(
      onTap: () {
        setState(() {
          _medioTransporte = value;
          _resultadoViaje = null;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryColor : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppTheme.primaryColor : Colors.grey[300]!,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(icono, style: const TextStyle(fontSize: 20)),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.white : AppTheme.textPrimary,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultItem(String icono, String valor, String label) {
    return Column(
      children: [
        Text(icono, style: const TextStyle(fontSize: 24)),
        const SizedBox(height: 4),
        Text(
          valor,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: AppTheme.primaryColor,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildParroquiaCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text('⛪', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 12),
          const Text(
            'Parroquia San Sebastián',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Aníbal Pinto 346, Purranque',
            style: TextStyle(color: Colors.grey[600]),
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () => _llamar('+56642351340'),
            icon: const Icon(Icons.phone),
            label: const Text('+56 64 235 1340'),
          ),
        ],
      ),
    );
  }

  Widget _buildAboutCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text('🦉', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 12),
          const Text(
            'PurranQUE.INFO',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Esta guía fue creada como un servicio público para los peregrinos de San Sebastián.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey[600]),
          ),
          const SizedBox(height: 16),
          const Text(
            'Versión 1.0.0',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _llamar(String numero) async {
    final uri = Uri.parse('tel:$numero');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }
}
