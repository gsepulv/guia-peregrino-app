import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../data/app_data.dart';
import '../models/evento.dart';
import '../widgets/countdown_widget.dart';
import '../widgets/evento_card.dart';

class HorariosScreen extends StatefulWidget {
  const HorariosScreen({super.key});

  @override
  State<HorariosScreen> createState() => _HorariosScreenState();
}

class _HorariosScreenState extends State<HorariosScreen> {
  String _filtroActual = 'todos';

  List<Evento> get _eventosFiltrados {
    if (_filtroActual == 'todos') {
      return AppData.eventos;
    }
    return AppData.eventos.where((e) => e.tipo == _filtroActual).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App Bar con gradiente
          SliverAppBar(
            expandedHeight: 120,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: const Text(
                'Guía del Peregrino',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              centerTitle: true,
              background: Container(
                decoration: const BoxDecoration(
                  gradient: AppTheme.headerGradient,
                ),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Text(
                      '✝️',
                      style: TextStyle(
                        fontSize: 40,
                        color: Colors.white.withOpacity(0.3),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          
          // Contenido
          SliverToBoxAdapter(
            child: Column(
              children: [
                // Contador
                const CountdownWidget(),
                
                // Subtítulo
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      const Text(
                        '📋 Cronograma del Día',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${_eventosFiltrados.length} eventos',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 12),
                
                // Filtros
                _buildFiltros(),
                
                const SizedBox(height: 8),
              ],
            ),
          ),
          
          // Lista de eventos
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final evento = _eventosFiltrados[index];
                return EventoCard(evento: evento);
              },
              childCount: _eventosFiltrados.length,
            ),
          ),
          
          // Espacio al final
          const SliverToBoxAdapter(
            child: SizedBox(height: 100),
          ),
        ],
      ),
    );
  }

  Widget _buildFiltros() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _buildFiltroChip('todos', 'Todo', '📅'),
          const SizedBox(width: 8),
          _buildFiltroChip('misa', 'Misas', '⛪'),
          const SizedBox(width: 8),
          _buildFiltroChip('procesion', 'Procesión', '🚶'),
          const SizedBox(width: 8),
          _buildFiltroChip('actividad', 'Actividades', '🎪'),
        ],
      ),
    );
  }

  Widget _buildFiltroChip(String filtro, String label, String icono) {
    final isSelected = _filtroActual == filtro;
    
    return GestureDetector(
      onTap: () {
        setState(() {
          _filtroActual = filtro;
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryColor : Colors.white,
          borderRadius: BorderRadius.circular(25),
          border: Border.all(
            color: isSelected ? AppTheme.primaryColor : Colors.grey[300]!,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppTheme.primaryColor.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Row(
          children: [
            Text(icono, style: const TextStyle(fontSize: 16)),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.white : AppTheme.textPrimary,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
