import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../data/app_data.dart';
import '../models/checklist_item.dart';
import '../services/storage_service.dart';

class ChecklistScreen extends StatefulWidget {
  const ChecklistScreen({super.key});

  @override
  State<ChecklistScreen> createState() => _ChecklistScreenState();
}

class _ChecklistScreenState extends State<ChecklistScreen> {
  late List<ChecklistItem> _items;
  final StorageService _storage = StorageService();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _items = AppData.checklistItems.map((e) => ChecklistItem(
      id: e.id,
      nombre: e.nombre,
      categoria: e.categoria,
      icono: e.icono,
      completado: false,
    )).toList();
    _loadChecklistState();
  }

  Future<void> _loadChecklistState() async {
    final savedState = await _storage.loadChecklistState();
    setState(() {
      for (var item in _items) {
        if (savedState.containsKey(item.id)) {
          item.completado = savedState[item.id]!;
        }
      }
      _isLoading = false;
    });
  }

  Future<void> _toggleItem(ChecklistItem item) async {
    setState(() {
      item.completado = !item.completado;
    });
    
    final state = {for (var i in _items) i.id: i.completado};
    await _storage.saveChecklistState(state);
  }

  int get _completedCount => _items.where((e) => e.completado).length;
  double get _progress => _items.isEmpty ? 0 : _completedCount / _items.length;

  Map<String, List<ChecklistItem>> get _itemsByCategory {
    final map = <String, List<ChecklistItem>>{};
    for (var item in _items) {
      map.putIfAbsent(item.categoria, () => []).add(item);
    }
    return map;
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('🎒 Tu Mochila'),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: AppTheme.headerGradient,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _resetChecklist,
            tooltip: 'Reiniciar',
          ),
        ],
      ),
      body: Column(
        children: [
          // Barra de progreso
          _buildProgressSection(),
          
          // Lista de items
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.only(bottom: 100),
              itemCount: _itemsByCategory.keys.length,
              itemBuilder: (context, index) {
                final categoria = _itemsByCategory.keys.elementAt(index);
                final items = _itemsByCategory[categoria]!;
                return _buildCategorySection(categoria, items);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressSection() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '$_completedCount de ${_items.length} items',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                '${(_progress * 100).toInt()}%',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: _progress == 1 ? AppTheme.accentColor : AppTheme.primaryColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: _progress,
              minHeight: 12,
              backgroundColor: Colors.grey[200],
              valueColor: AlwaysStoppedAnimation<Color>(
                _progress == 1 ? AppTheme.accentColor : AppTheme.primaryColor,
              ),
            ),
          ),
          if (_progress == 1) ...[
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('🎉', style: TextStyle(fontSize: 20)),
                const SizedBox(width: 8),
                Text(
                  '¡Mochila lista!',
                  style: TextStyle(
                    color: AppTheme.accentColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildCategorySection(String categoria, List<ChecklistItem> items) {
    final completedInCategory = items.where((e) => e.completado).length;
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              Text(
                categoria,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimary,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: completedInCategory == items.length
                      ? AppTheme.accentColor.withOpacity(0.1)
                      : Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '$completedInCategory/${items.length}',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: completedInCategory == items.length
                        ? AppTheme.accentColor
                        : Colors.grey[600],
                  ),
                ),
              ),
            ],
          ),
        ),
        ...items.map((item) => _buildChecklistItem(item)),
      ],
    );
  }

  Widget _buildChecklistItem(ChecklistItem item) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: item.completado 
            ? AppTheme.accentColor.withOpacity(0.05)
            : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: item.completado 
              ? AppTheme.accentColor.withOpacity(0.3)
              : Colors.grey[200]!,
        ),
      ),
      child: ListTile(
        onTap: () => _toggleItem(item),
        leading: Text(item.icono, style: const TextStyle(fontSize: 24)),
        title: Text(
          item.nombre,
          style: TextStyle(
            decoration: item.completado ? TextDecoration.lineThrough : null,
            color: item.completado ? Colors.grey[500] : AppTheme.textPrimary,
          ),
        ),
        trailing: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            color: item.completado ? AppTheme.accentColor : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: item.completado ? AppTheme.accentColor : Colors.grey[400]!,
              width: 2,
            ),
          ),
          child: item.completado
              ? const Icon(Icons.check, color: Colors.white, size: 18)
              : null,
        ),
      ),
    );
  }

  Future<void> _resetChecklist() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('¿Reiniciar checklist?'),
        content: const Text('Se desmarcarán todos los items.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Reiniciar'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() {
        for (var item in _items) {
          item.completado = false;
        }
      });
      await _storage.clearChecklist();
    }
  }
}
