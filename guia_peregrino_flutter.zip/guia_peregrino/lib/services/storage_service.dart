import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static const String _checklistKey = 'checklist_items';
  
  // Singleton
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Guardar estado del checklist
  Future<void> saveChecklistState(Map<String, bool> checklistState) async {
    if (_prefs == null) await init();
    await _prefs!.setString(_checklistKey, jsonEncode(checklistState));
  }

  // Cargar estado del checklist
  Future<Map<String, bool>> loadChecklistState() async {
    if (_prefs == null) await init();
    final String? data = _prefs!.getString(_checklistKey);
    if (data == null) return {};
    
    final Map<String, dynamic> decoded = jsonDecode(data);
    return decoded.map((key, value) => MapEntry(key, value as bool));
  }

  // Limpiar checklist
  Future<void> clearChecklist() async {
    if (_prefs == null) await init();
    await _prefs!.remove(_checklistKey);
  }
}
