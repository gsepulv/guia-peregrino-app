class ChecklistItem {
  final String id;
  final String nombre;
  final String categoria;
  final String icono;
  bool completado;

  ChecklistItem({
    required this.id,
    required this.nombre,
    required this.categoria,
    required this.icono,
    this.completado = false,
  });

  factory ChecklistItem.fromJson(Map<String, dynamic> json) {
    return ChecklistItem(
      id: json['id'] ?? '',
      nombre: json['nombre'] ?? '',
      categoria: json['categoria'] ?? '',
      icono: json['icono'] ?? '📦',
      completado: json['completado'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nombre': nombre,
      'categoria': categoria,
      'icono': icono,
      'completado': completado,
    };
  }

  ChecklistItem copyWith({bool? completado}) {
    return ChecklistItem(
      id: id,
      nombre: nombre,
      categoria: categoria,
      icono: icono,
      completado: completado ?? this.completado,
    );
  }
}
