class Evento {
  final String id;
  final String titulo;
  final String hora;
  final String? horaFin;
  final String descripcion;
  final String ubicacion;
  final String tipo; // 'misa', 'procesion', 'actividad'
  final String icono;
  final bool destacado;

  Evento({
    required this.id,
    required this.titulo,
    required this.hora,
    this.horaFin,
    required this.descripcion,
    required this.ubicacion,
    required this.tipo,
    required this.icono,
    this.destacado = false,
  });

  factory Evento.fromJson(Map<String, dynamic> json) {
    return Evento(
      id: json['id'] ?? '',
      titulo: json['titulo'] ?? '',
      hora: json['hora'] ?? '',
      horaFin: json['horaFin'],
      descripcion: json['descripcion'] ?? '',
      ubicacion: json['ubicacion'] ?? '',
      tipo: json['tipo'] ?? 'actividad',
      icono: json['icono'] ?? '📅',
      destacado: json['destacado'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'titulo': titulo,
      'hora': hora,
      'horaFin': horaFin,
      'descripcion': descripcion,
      'ubicacion': ubicacion,
      'tipo': tipo,
      'icono': icono,
      'destacado': destacado,
    };
  }
}
