class PuntoInteres {
  final String id;
  final String nombre;
  final String categoria; // 'comida', 'alojamiento', 'bencina', 'cajero', 'farmacia', 'importante'
  final String direccion;
  final String? telefono;
  final String icono;
  final double? latitud;
  final double? longitud;
  final String? horario;
  final String? descripcion;

  PuntoInteres({
    required this.id,
    required this.nombre,
    required this.categoria,
    required this.direccion,
    this.telefono,
    required this.icono,
    this.latitud,
    this.longitud,
    this.horario,
    this.descripcion,
  });

  factory PuntoInteres.fromJson(Map<String, dynamic> json) {
    return PuntoInteres(
      id: json['id'] ?? '',
      nombre: json['nombre'] ?? '',
      categoria: json['categoria'] ?? '',
      direccion: json['direccion'] ?? '',
      telefono: json['telefono'],
      icono: json['icono'] ?? '📍',
      latitud: json['latitud']?.toDouble(),
      longitud: json['longitud']?.toDouble(),
      horario: json['horario'],
      descripcion: json['descripcion'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nombre': nombre,
      'categoria': categoria,
      'direccion': direccion,
      'telefono': telefono,
      'icono': icono,
      'latitud': latitud,
      'longitud': longitud,
      'horario': horario,
      'descripcion': descripcion,
    };
  }
}
