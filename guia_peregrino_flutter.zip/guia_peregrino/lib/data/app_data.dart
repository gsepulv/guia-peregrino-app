import '../models/evento.dart';
import '../models/checklist_item.dart';
import '../models/punto_interes.dart';

class AppData {
  // Fecha del evento
  static final DateTime fechaEvento = DateTime(2026, 1, 20);
  
  // Cronograma de eventos del 20 de enero 2026
  static final List<Evento> eventos = [
    Evento(
      id: '1',
      titulo: 'Misa de Aurora',
      hora: '06:00',
      descripcion: 'Primera misa del día en honor a San Sebastián',
      ubicacion: 'Templo Parroquial',
      tipo: 'misa',
      icono: '⛪',
      destacado: true,
    ),
    Evento(
      id: '2',
      titulo: 'Misa',
      hora: '08:00',
      descripcion: 'Santa Misa',
      ubicacion: 'Templo Parroquial',
      tipo: 'misa',
      icono: '⛪',
    ),
    Evento(
      id: '3',
      titulo: 'Misa',
      hora: '10:00',
      descripcion: 'Santa Misa',
      ubicacion: 'Templo Parroquial',
      tipo: 'misa',
      icono: '⛪',
    ),
    Evento(
      id: '4',
      titulo: 'Misa Solemne',
      hora: '12:00',
      descripcion: 'Misa principal de la festividad',
      ubicacion: 'Templo Parroquial',
      tipo: 'misa',
      icono: '⛪',
      destacado: true,
    ),
    Evento(
      id: '5',
      titulo: 'Procesión Principal',
      hora: '16:00',
      horaFin: '18:00',
      descripcion: 'Procesión con la imagen de San Sebastián por las calles de Purranque',
      ubicacion: 'Desde Templo Parroquial',
      tipo: 'procesion',
      icono: '🚶',
      destacado: true,
    ),
    Evento(
      id: '6',
      titulo: 'Misa de Cierre',
      hora: '18:00',
      descripcion: 'Misa de finalización de la festividad',
      ubicacion: 'Templo Parroquial',
      tipo: 'misa',
      icono: '⛪',
    ),
    Evento(
      id: '7',
      titulo: 'Misa',
      hora: '20:00',
      descripcion: 'Última misa del día',
      ubicacion: 'Templo Parroquial',
      tipo: 'misa',
      icono: '⛪',
    ),
    Evento(
      id: '8',
      titulo: 'Feria Comercial',
      hora: '09:00',
      horaFin: '22:00',
      descripcion: 'Feria con puestos de comida, artesanía y productos locales',
      ubicacion: 'Centro de Purranque',
      tipo: 'actividad',
      icono: '🎪',
    ),
    Evento(
      id: '9',
      titulo: 'Zona Familiar',
      hora: '10:00',
      horaFin: '20:00',
      descripcion: 'Espacio recreativo con juegos, palomitas, helados y más',
      ubicacion: 'Estadio Municipal',
      tipo: 'actividad',
      icono: '👨‍👩‍👧‍👦',
    ),
  ];

  // Items del checklist del peregrino
  static final List<ChecklistItem> checklistItems = [
    // Documentos
    ChecklistItem(id: 'doc1', nombre: 'Cédula de identidad', categoria: 'Documentos', icono: '🪪'),
    ChecklistItem(id: 'doc2', nombre: 'Dinero en efectivo', categoria: 'Documentos', icono: '💵'),
    ChecklistItem(id: 'doc3', nombre: 'Tarjeta de salud', categoria: 'Documentos', icono: '🏥'),
    
    // Vestimenta
    ChecklistItem(id: 'ves1', nombre: 'Ropa cómoda', categoria: 'Vestimenta', icono: '👕'),
    ChecklistItem(id: 'ves2', nombre: 'Zapatos cómodos', categoria: 'Vestimenta', icono: '👟'),
    ChecklistItem(id: 'ves3', nombre: 'Sombrero o gorra', categoria: 'Vestimenta', icono: '🧢'),
    ChecklistItem(id: 'ves4', nombre: 'Chaqueta impermeable', categoria: 'Vestimenta', icono: '🧥'),
    
    // Hidratación y alimentación
    ChecklistItem(id: 'ali1', nombre: 'Botella de agua', categoria: 'Hidratación', icono: '💧'),
    ChecklistItem(id: 'ali2', nombre: 'Snacks o colaciones', categoria: 'Hidratación', icono: '🍎'),
    
    // Protección
    ChecklistItem(id: 'pro1', nombre: 'Protector solar', categoria: 'Protección', icono: '🧴'),
    ChecklistItem(id: 'pro2', nombre: 'Lentes de sol', categoria: 'Protección', icono: '🕶️'),
    
    // Salud
    ChecklistItem(id: 'sal1', nombre: 'Medicamentos personales', categoria: 'Salud', icono: '💊'),
    ChecklistItem(id: 'sal2', nombre: 'Parches para ampollas', categoria: 'Salud', icono: '🩹'),
    
    // Tecnología
    ChecklistItem(id: 'tec1', nombre: 'Celular cargado', categoria: 'Tecnología', icono: '📱'),
    ChecklistItem(id: 'tec2', nombre: 'Cargador portátil', categoria: 'Tecnología', icono: '🔋'),
    
    // Religioso
    ChecklistItem(id: 'rel1', nombre: 'Rosario', categoria: 'Religioso', icono: '📿'),
    ChecklistItem(id: 'rel2', nombre: 'Vela', categoria: 'Religioso', icono: '🕯️'),
  ];

  // Puntos de interés
  static final List<PuntoInteres> puntosInteres = [
    // Lugares importantes
    PuntoInteres(
      id: 'imp1',
      nombre: 'Templo Parroquial San Sebastián',
      categoria: 'importante',
      direccion: 'Aníbal Pinto 346',
      telefono: '+56 64 235 1340',
      icono: '⛪',
      descripcion: 'Templo principal de la festividad',
    ),
    PuntoInteres(
      id: 'imp2',
      nombre: 'Santuario',
      categoria: 'importante',
      direccion: 'Aníbal Pinto 326',
      icono: '🛐',
    ),
    PuntoInteres(
      id: 'imp3',
      nombre: 'Plaza de Armas',
      categoria: 'importante',
      direccion: 'Centro de Purranque',
      icono: '🌳',
    ),
    PuntoInteres(
      id: 'imp4',
      nombre: 'Municipalidad de Purranque',
      categoria: 'importante',
      direccion: 'Pedro Montt 249',
      telefono: '+56 64 235 1135',
      icono: '🏢',
    ),
    
    // Farmacias
    PuntoInteres(
      id: 'far1',
      nombre: 'Farmacia Cruz Verde',
      categoria: 'farmacia',
      direccion: 'Centro de Purranque',
      icono: '💊',
    ),
    
    // Cajeros
    PuntoInteres(
      id: 'caj1',
      nombre: 'Cajero BancoEstado',
      categoria: 'cajero',
      direccion: 'Centro de Purranque',
      icono: '🏧',
    ),
    
    // Bencineras
    PuntoInteres(
      id: 'ben1',
      nombre: 'Copec',
      categoria: 'bencina',
      direccion: 'Ruta 5 Sur',
      icono: '⛽',
    ),
  ];

  // Contactos de emergencia
  static final Map<String, String> emergencias = {
    'Ambulancia (SAMU)': '131',
    'Bomberos': '132',
    'Carabineros': '133',
    'Parroquia San Sebastián': '+56 64 235 1340',
  };

  // Datos de calculadora de viaje
  static final Map<String, Map<String, dynamic>> origenes = {
    'Osorno (Centro)': {'distancia': 28, 'tiempo': 25},
    'Puerto Octay': {'distancia': 52, 'tiempo': 45},
    'Río Negro': {'distancia': 12, 'tiempo': 12},
    'Puyehue (Entre Lagos)': {'distancia': 70, 'tiempo': 60},
    'San Juan de la Costa': {'distancia': 75, 'tiempo': 70},
    'Bahía Mansa': {'distancia': 95, 'tiempo': 90},
    'Puerto Montt': {'distancia': 90, 'tiempo': 75},
    'Puerto Varas': {'distancia': 75, 'tiempo': 60},
    'Frutillar': {'distancia': 60, 'tiempo': 50},
    'La Unión': {'distancia': 65, 'tiempo': 55},
    'Río Bueno': {'distancia': 45, 'tiempo': 40},
  };
}
