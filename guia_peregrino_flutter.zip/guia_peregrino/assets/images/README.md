# Assets de la App

## Imágenes requeridas

Coloca aquí las siguientes imágenes:

1. **buho.png** - Imagen del Búho Constantino (mascota de PurranQUE.INFO)
   - Tamaño recomendado: 512x512 px
   - Formato: PNG con fondo transparente

2. **ic_launcher.png** - Icono de la app (opcional, se puede generar)
   - Tamaño: 1024x1024 px

## Generar iconos de la app

Puedes usar el paquete `flutter_launcher_icons` para generar automáticamente
todos los iconos necesarios a partir de una imagen base.

1. Agrega al pubspec.yaml:
```yaml
dev_dependencies:
  flutter_launcher_icons: ^0.13.1

flutter_launcher_icons:
  android: true
  ios: true
  image_path: "assets/images/ic_launcher.png"
```

2. Ejecuta:
```bash
flutter pub get
flutter pub run flutter_launcher_icons
```
